#include "Computer.h"

Computer::Computer(){
    cname = "Computer";
}
    char Computer::makeMove(){
        char move = 'R';
        return move;
    }
    string Computer::getName(){
        return cname;
    }